### Group Members
Abdulrahman Almalki (a1695860) (a1695860@student.adelaide.edu.au)
Viet Anh Do (a1759960) (a1759960@student.adelaide.edu.au)
Clint Gamlin (a1038415) (a1038415@student.adelaide.edu.au)
Qinghao Liu (a1739069) (a1739069@student.adelaide.edu.au)
Lujun Weng (a1698575) (a1698575@student.adelaide.edu.au)
Suraj Yathish (a1711355) (a1711355@student.adelaide.edu.au)

### Description of files
- results.txt: Raw data for Exercise 2, 6 and 7.
- Report.pdf: Our report for this assignment, including results for each exercise, each member's responsibilty and contribution, tables showing the results of our best algorithms.
- src: Folder containing all source code.
- README.txt: This file.

### Instructions to run the code
#### The following instructions show how to run the code and options that we can use.
Compile:
javac tsp.java

Run:
java tsp [OPTIONS] mapfilename

Options:
-r(int)		Repeat the method (int) number of times, eg: -r30
-l2		Local search implemented with inversion (2-opt)
-l3		Local search implemented with jump (3-opt)
-l4		Local search implemented with exchange (4-opt)
-p(int)		Population search with (int) number of individuals, eg: -p100
-g(int)		Run population method for (int) number of generations, eg: -g10000
-d(int)		Display the best population result every (int) generation, eg: -d1000
-mn(int)	Insert mutation (int)% of the time
-ms(int)	Swap mutation (int)% of the time
-mv(int)	Inversion mutation (int)% of the time
-sf		Fitness proportionate selection
-st(int)		Tournament selection from (int)% of the population, eg: -st10
-xc(int)		Cycle crossover (int)% of the time
-xe(int)		Edge Recombination crossover (int)% of the time
-xo(int)		Order crossover (int)% of the time
-xp(int)		PMX crossover (int)% of the time
-i(int)                   InverOver, with (int)% chance of a child  choosing itself rather than a parent

#### The following examples show how to use the command for localsearch, evolutionary algorithms and Inver-over.
`java tsp -r100 -l2 ../testfiles/eil51.tsp`
Repeat 100 times for local search 2-opt

`java tsp -r10 -g20000 -xo100 -st10 -p100 -ms100 ../testfiles/eil51.tsp`
Repeat 10 times with 20000 generations with order crossover 100% of the time, tournament selection using 10% of population, a population of 100, and swap mutation 100% of the time

`java tsp -r30 -p100 -g20000 -i2 ../testfiles/eil51.tsp`
Repeat 30 times, population 100, for 20000 generations, InverOver with its probability selector set at 2% (2% chance a child uses itself rather than another parent)

#### The following shows a sample output from running the command
$ java tsp -r10 -g20000 -xo100 -st10 -p100 -ms100 ../testfiles/eil51.tsp 
Min: 515.0156863415343
Max: 585.7135983740507
Avg: 548.7269805577514
Std: 24.133543036165847
